﻿using System;

namespace ConnectedModeApp
{
    public class Event
    {
        public int Id { get; set; }
        public DateTime EventDate { get; set; }
        public string Description { get; set; }
    }
}
