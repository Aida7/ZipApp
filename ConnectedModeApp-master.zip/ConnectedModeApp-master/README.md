# ConnectedModeApp
Homework
------
Создать базу данных MyDB.
Создать простейшее приложение WinForms, позволяющее пользователю подключаться к базе данных MyDB,
используя аутентификацию SQL Server. Для построения строки подключения использовать SqlConnectionStringBuilder.
